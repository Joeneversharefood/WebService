#define LOCAL
#include <iostream>
#include <cstdio>
#include <cstring>
#include <stack>

using namespace std;

int dir[2][2] = { {1, 0}, {0, 1} }; // 向下或向右方向搜索
int mp[101][101]; // int mp[100][100]; // 限制矩阵的大小最大为 100 * 100
bool flag = false; // 判断是否找到
int sum = 0xfffffff;

struct Node {
    int x;
    int y;
};

struct Path {
    int start;
    int end;
};

stack<Node> stk, res, ack;

void dfs(int x, int y, int n, int minV)
{
    if(x == n - 1 && y == n - 1) {
        minV += mp[x][y];
        if(minV < sum) {
            sum = minV;
            res = stk;
        }
        return;
    }
    if(x + 1 < n && y < n) {
        Node tmp;
        tmp.x = y;
        tmp.y = x + 1;
        stk.push(tmp);
        dfs(x + 1, y, n, minV + mp[x][y]);
        stk.pop();
    }
    if(x < n && y + 1 < n) {
        Node tmp;
        tmp.x = y + 1;
        tmp.y = x;
        stk.push(tmp);
        dfs(x, y + 1, n, minV + mp[x][y]);
        stk.pop();
    }
}

int main()
{

    #ifdef LOCAL
    freopen("input.txt", "r", stdin);
    #endif

    int n; // 输入 N，表示 N * N 的矩阵
    // 输入矩阵大小
    scanf("%d", &n);
    // 输入矩阵
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &mp[i][j]);
        }
    }

    // 从(0, 0)位置开始搜索
    dfs(0, 0, n, 0);

    printf("%d\n", sum);
    
    while(!res.empty()) {
        Node cur = res.top();
        res.pop();

        printf("(%d, %d)\n", cur.x, cur.y);
    }
    printf("(0, 0)\n");
    return 0;
}

/*
4
1 0 0 7 
9 1 1 1 
5 8 7 1 
6 1 9 8 
5
7 4 5 9 6 
5 5 3 7 6 
7 1 6 8 8 
4 2 7 9 4 
1 4 5 5 0 
6
0 4 1 5 1 2 
7 5 0 8 9 5 
7 5 0 4 2 2 
0 1 6 4 2 1 
5 6 4 7 9 1 
2 3 0 5 4 2 

*/

/*
12
(1,1),(1,2),(1,3),(2,3),(2,4),(3,4),(4,4)
33
(1,1),(1,2),(2,2),(3,2),(4,2),(5,2),(5,3),(5,4),(5,5)
17
(1,1),(1,2),(1,3),(2,3),(3,3),(3,4),(3,5),(3,6),(4,6),(5,6),(6,6)
*/
