#define LOCAL
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>

using namespace std;

int n;
int mp[101][101];
int dp[101][101];
int sum = 0x3f3f3f3f;
int path[101][101];

void dp_solve()
{
    path[0][0] = -1;
    dp[0][0] = mp[0][0];

    for(int i = 1; i < n; i++) {
        dp[0][i] = dp[0][i-1] + mp[0][i];
        path[0][i] = 1;
    }
    for(int i = 1; i < n; i++) {
        // 上方
        dp[i][0] = dp[i-1][0] + mp[i][0];
        path[i][0] = 2;
    }
    for(int i = 1; i < n; i++) {
        for(int j = 1; j < n; j++) {
            if(dp[i-1][j] > dp[i][j-1]) {
                // 左方
                dp[i][j] = dp[i][j-1] + mp[i][j];
                path[i][j] = 1;
            }
            else {
                dp[i][j] = dp[i-1][j] + mp[i][j];
                path[i][j] = 2;
            }
        }
    }
}

void print(int x, int y)
{
    if (path[x][y] == -1)
    {
        cout << "(" << x << " , " << y << ")" << endl;
        return;
    }
    if (path[x][y] == 1)
    {
        print(x, y - 1);
    }
    if (path[x][y] == 2)
    {
        print(x - 1, y);
    }
    cout << "(" << y << " , " << x << ")" << endl;
}

int main()
{

    #ifdef LOCAL
    freopen("input.txt", "r", stdin);
    #endif

    scanf("%d", &n);

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            scanf("%d", &mp[i][j]);
        }
    }

    dp_solve();

    printf("%d\n", dp[n-1][n-1]);

    print(n-1, n-1);

    return 0;
}

/*
4
1 0 0 7 
9 1 1 1 
5 8 7 1 
6 1 9 8 
5
7 4 5 9 6 
5 5 3 7 6 
7 1 6 8 8 
4 2 7 9 4 
1 4 5 5 0 
6
0 4 1 5 1 2 
7 5 0 8 9 5 
7 5 0 4 2 2 
0 1 6 4 2 1 
5 6 4 7 9 1 
2 3 0 5 4 2 

*/

/*
12
(1,1),(1,2),(1,3),(2,3),(2,4),(3,4),(4,4)
33
(1,1),(1,2),(2,2),(3,2),(4,2),(5,2),(5,3),(5,4),(5,5)
17
(1,1),(1,2),(1,3),(2,3),(3,3),(3,4),(3,5),(3,6),(4,6),(5,6),(6,6)
*/
