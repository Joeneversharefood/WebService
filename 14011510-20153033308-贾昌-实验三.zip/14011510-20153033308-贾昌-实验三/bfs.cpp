#define LOCAL
#include <iostream>
#include <cstdio>
#include <queue>
#include <cstring>
#include <stack>

using namespace std;

int n; // 数字矩阵维数
int mp[101][101]; // 数字矩阵，限制大小为 101 * 101
int ans = 0x3f3f3f3f;

struct Node {
    int x;
    int y;
    int value;

    stack<Node> stac;
};

struct Path {
    int start;
    int end;
};

stack<Node> stk, res;
Node ret;

void bfs()
{
    queue<Node> que;

    Node st;
    Node now;
    Node pb;
    st.x = 0, st.y = 0, st.value = 0;
    Node init;
    st.stac.push(st);
    que.push(st);

    while(!que.empty()) {
        now = que.front();
        que.pop();

        int x = now.x;
        int y = now.y;
        int val = now.value;

        if(x == n - 1 && y == n - 1) {
            if(ans > val + mp[n-1][n-1]) {
                ans = val + mp[n-1][n-1];
                ret = now;
            }
            continue;
        }
        if(x + 1 < n && y < n) {
            Node tmp = now;
            Node save;
            save.x = y;
            save.y = x + 1;
            tmp.stac.push(save);
            tmp.x++;
            tmp.value += mp[x][y];
            que.push(tmp);
        }
        if(x < n && y + 1 < n) {
            Node tmp = now;
            Node save;
            save.x = y + 1;
            save.y = x;
            tmp.stac.push(save);
            tmp.y++;
            tmp.value += mp[x][y];
            que.push(tmp);
        }
    }
}

int main()
{

    #ifdef LOCAL
    freopen("input.txt", "r", stdin);
    #endif

    scanf("%d", &n); // 输入矩阵维数
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &mp[i][j]);
        }
    }

    bfs();

    printf("%d\n", ans);

    while(!ret.stac.empty()) {
        Node nd = ret.stac.top();
        ret.stac.pop();
        printf("(%d, %d)\n", nd.x, nd.y);
    }

    return 0;

}

/*
4
1 0 0 7 
9 1 1 1 
5 8 7 1 
6 1 9 8 
5
7 4 5 9 6 
5 5 3 7 6 
7 1 6 8 8 
4 2 7 9 4 
1 4 5 5 0 
6
0 4 1 5 1 2 
7 5 0 8 9 5 
7 5 0 4 2 2 
0 1 6 4 2 1 
5 6 4 7 9 1 
2 3 0 5 4 2 

*/

/*
12
(1,1),(1,2),(1,3),(2,3),(2,4),(3,4),(4,4)
33
(1,1),(1,2),(2,2),(3,2),(4,2),(5,2),(5,3),(5,4),(5,5)
17
(1,1),(1,2),(1,3),(2,3),(3,3),(3,4),(3,5),(3,6),(4,6),(5,6),(6,6)
*/
